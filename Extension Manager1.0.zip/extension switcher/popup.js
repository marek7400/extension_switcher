document.addEventListener('DOMContentLoaded', async () => {
    // DOM Element References
    const listContainer = document.getElementById('extensions-list');
    const globalToggle = document.getElementById('global-toggle');
    const allExtensionsToggle = document.getElementById('all-extensions-toggle');
    const sortToggle = document.getElementById('sort-toggle');
    const exportButton = document.getElementById('export-button');
    const importButton = document.getElementById('import-button');
    const importInput = document.getElementById('import-input');
    // Modal elements
    const exportChoiceModal = document.getElementById('export-choice-modal');
    const exportTxtBtn = document.getElementById('export-txt-btn');
    const exportHtmlBtn = document.getElementById('export-html-btn');
    const exportCancelBtn = document.getElementById('export-cancel-btn');

    // Storage Keys
    const SORT_MODE_KEY = 'extension_sort_mode';

    // --- HELPER FUNCTIONS ---

    /**
     * Handles getting a usable URL for an extension's icon.
     * If it's a file:// URL, it fetches the file and converts it to a Data URL (base64).
     * This is necessary because <img> tags cannot directly load file:// sources in extensions.
     * The "host_permissions": ["file:///*"] in manifest.json is required for this to work.
     * @param {string} url The original icon URL from the management API.
     * @returns {Promise<string>} A promise that resolves to a usable image source URL.
     */
    const getIconSrc = (url) => {
        if (!url || !url.startsWith('file://')) {
            return Promise.resolve(url || 'icons/icon16.png');
        }
        return new Promise((resolve) => {
            fetch(url)
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.blob();
                })
                .then(blob => {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve(reader.result);
                    reader.onerror = () => resolve('icons/icon16.png');
                    reader.readAsDataURL(blob);
                })
                .catch(() => resolve('icons/icon16.png'));
        });
    };

    const convertImageElementToBase64 = (imgElement) => {
        try {
            // Ensure the image is loaded, especially for cross-origin sources
            if (!imgElement.complete) {
                console.warn("Image for base64 conversion is not yet loaded.", imgElement.src);
                // Return a placeholder or handle asynchronously if necessary
                return null;
            }
            const canvas = document.createElement('canvas');
            const width = imgElement.naturalWidth || 16;
            const height = imgElement.naturalHeight || 16;
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(imgElement, 0, 0, width, height);
            return canvas.toDataURL('image/png');
        } catch (error) {
            console.error(`Canvas operation failed for image: ${imgElement.src}`, error);
            // Fallback for tainted canvas
            return null;
        }
    };

    const generateHtmlReport = (extensionsWithIcons) => {
        const date = new Date();
        const formattedDate = `${String(date.getDate()).padStart(2, '0')}-${String(date.getMonth() + 1).padStart(2, '0')}-${date.getFullYear()}`;
        
        const listItems = extensionsWithIcons.map((ext, index) => {
            const status = ext.enabled ? '<span style="color: green;">Enabled</span>' : '<span style="color: red;">Disabled</span>';
            const isLocal = ext.installType === 'development';
            
            const cwsUrl = `https://chromewebstore.google.com/detail/${ext.id}`;
            const statsUrl = `https://chrome-stats.com/d/${ext.id}`;

            const linksHtml = `
                <div style="margin-bottom: 5px;">1. <a href="${cwsUrl}" target="_blank">Chrome Web Store${isLocal ? '?' : ''}</a></div>
                <div>2. <a href="${statsUrl}" target="_blank">FULL INFO chrome-stats.com${isLocal ? '?' : ''}</a></div>
            `;
            
            const nameHtml = isLocal 
                ? `${ext.name} <em style="color:#666; font-size:0.9em;">(Local)</em>`
                : ext.name;

            const iconHtml = ext.iconDataUrl
                ? `<img src="${ext.iconDataUrl}" width="16" height="16" style="vertical-align: middle; margin-right: 8px;">` 
                : '<span style="display: inline-block; width: 16px; height: 16px; margin-right: 8px; border: 1px dotted #ccc;" title="Icon not available"></span>';

            return `
                <tr>
                    <td>${index + 1}</td>
                    <td>
                        ${iconHtml}
                        ${nameHtml}
                    </td>
                    <td>${ext.version}</td>
                    <td>${status}</td>
                    <td>${linksHtml}</td>
                </tr>
            `;
        }).join('');

        return `
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Chrome Extensions List</title>
                <style>
                    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 2em; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: middle; }
                    th { background-color: #f2f2f2; }
                    tr:nth-child(even) { background-color: #f9f9f9; }
                    tr:hover { background-color: #f1f1f1; }
                    a { color: #0066cc; text-decoration: none; }
                    a:hover { text-decoration: underline; }
                </style>
            </head>
            <body>
                <h1>Chrome Extensions List</h1>
                <p>Generated on: ${formattedDate}</p>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Version</th>
                            <th>Status</th>
                            <th>Links</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${listItems}
                    </tbody>
                </table>
            </body>
            </html>
        `;
    };

    // --- EXPORT LOGIC ---

    const runExport = async (format) => {
        exportChoiceModal.style.display = 'none';
        const extensions = await chrome.management.getAll();
        extensions.sort((a, b) => {
            if (a.enabled !== b.enabled) return b.enabled - a.enabled;
            return a.name.localeCompare(b.name);
        });
        const now = new Date();
        const day = String(now.getDate()).padStart(2, '0');
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const year = now.getFullYear();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const timestamp = `${day}-${month}-${year}_${hours}-${minutes}`;
        const downloadFile = (blob, filename) => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        };

        if (format === 'html') {
            const iconDataUrlMap = new Map();
            // This is crucial: we query the icons that are ACTUALLY RENDERED in the popup.
            const iconElements = document.querySelectorAll('.extension-icon');

            for (const imgEl of iconElements) {
                // The extension ID is stored in a data attribute on the icon itself.
                const extId = imgEl.dataset.extensionId;
                const dataUrl = convertImageElementToBase64(imgEl);
                if (extId && dataUrl) {
                    iconDataUrlMap.set(extId, dataUrl);
                }
            }

            // Create a fallback icon in base64 format just in case
            const fallbackImg = new Image();
            fallbackImg.src = chrome.runtime.getURL('icons/icon16.png');
            // We must wait for the fallback image to load before we can convert it
            await new Promise(resolve => { fallbackImg.onload = resolve; });
            const fallbackIconDataUrl = convertImageElementToBase64(fallbackImg);

            // Enrich the extensions array with the base64 icon data
            const extensionsWithDataUrls = extensions.map(ext => ({
                ...ext,
                iconDataUrl: iconDataUrlMap.get(ext.id) || fallbackIconDataUrl
            }));

            const htmlContent = generateHtmlReport(extensionsWithDataUrls);
            const blob = new Blob([htmlContent], { type: 'text/html' });
            downloadFile(blob, `chrome_extensions_list_${timestamp}.html`);

        } else {
            const processedForTxt = extensions.map(ext => {
                let sourceUrl = 'Not available';
                if (ext.installType === 'normal') {
                    sourceUrl = `https://chromewebstore.google.com/detail/${ext.id}`;
                } else if (ext.installType === 'development') {
                    const webstoreCheckUrl = `https://chromewebstore.google.com/detail/${ext.id}`;
                    sourceUrl = `Local (unpacked) - available? ${webstoreCheckUrl}`;
                } else if (ext.homepageUrl) {
                    sourceUrl = ext.homepageUrl;
                }
                return { name: ext.name, id: ext.id, version: ext.version, enabled: ext.enabled, type: ext.type, url: sourceUrl, fullInfoUrl: `https://chrome-stats.com/d/${ext.id}` };
            });
            const jsonString = JSON.stringify(processedForTxt, null, 2);
            const blob = new Blob([jsonString], { type: 'text/plain' });
            downloadFile(blob, `chrome_extensions_list_${timestamp}.txt`);
        }
    };

    const handleImportClick = () => {
        importInput.click();
    };

    const handleFileSelect = async (event) => {
        const file = event.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                if (!Array.isArray(importedData)) throw new Error("Import file must contain an array of extensions.");
                const installedExtensions = await chrome.management.getAll();
                const installedMap = new Map(installedExtensions.map(ext => [ext.id, ext]));
                const updatePromises = [];
                for (const importedExt of importedData) {
                    const installedExt = installedMap.get(importedExt.id);
                    if (installedExt && installedExt.enabled !== importedExt.enabled) {
                        updatePromises.push(safeSetEnabled(installedExt.id, importedExt.enabled));
                    }
                }
                if (updatePromises.length > 0) {
                    await Promise.all(updatePromises);
                    alert(`Updated the state of ${updatePromises.length} extensions.`);
                } else {
                    alert("No extensions found to update or states are already in sync.");
                }
                await renderExtensionsList();
                await initializeAllToggleStates();
            } catch (error) {
                alert(`Error importing file: ${error.message}`);
                console.error("Import Error:", error);
            } finally {
                event.target.value = null;
            }
        };
        reader.readAsText(file);
    };

    const safeSetEnabled = async (id, state) => {
        try {
            await chrome.management.setEnabled(id, state);
        } catch (error) {
            console.warn(`Could not change state for extension ${id}. It might require manual user interaction.`, error);
        }
    };

    // --- MAIN EXTENSION LOGIC (LISTING, TOGGLES) ---
    const renderExtensionsList = async () => {
        listContainer.innerHTML = '';
        const extensions = await chrome.management.getAll();
        const sortByAZ = sortToggle.checked;
        if (sortByAZ) {
            extensions.sort((a, b) => a.name.localeCompare(b.name));
        } else {
            extensions.sort((a, b) => {
                if (a.enabled === b.enabled) return a.name.localeCompare(b.name);
                return b.enabled - a.enabled;
            });
        }
        
        const itemsToRender = await Promise.all(extensions.map(async ext => {
            if (ext.id === chrome.runtime.id) return null;

            const item = document.createElement('div');
            item.className = 'extension-item';
            if (!ext.enabled) item.classList.add('disabled');
            
            const icon = document.createElement('img');
            icon.className = 'extension-icon';
            icon.dataset.extensionId = ext.id; // Store ID for HTML export
            icon.crossOrigin = "anonymous"; // Important for canvas conversion
            const originalIconUrl = ext.icons?.find(i => i.size >= 16)?.url;
            icon.src = await getIconSrc(originalIconUrl);
            
            const name = document.createElement('span');
            name.className = 'extension-name';
            name.textContent = ext.name;
            
            const controls = document.createElement('div');
            controls.className = 'extension-controls';

            const detailsLink = document.createElement('a');
            detailsLink.className = 'details-link';
            detailsLink.textContent = 'Details / Errors';
            detailsLink.title = 'View details, Service Worker link, and errors';
            detailsLink.href = "#";
            detailsLink.addEventListener('click', (e) => { e.preventDefault(); chrome.tabs.create({ url: `chrome://extensions/?id=${ext.id}` }); });
            controls.appendChild(detailsLink);

            const isLocal = ext.installType === 'development';
            const needsPermission = ext.disabledReason === 'permissions_increase';

            if (needsPermission) {
                const warningIcon = document.createElement('span');
                warningIcon.className = 'permission-warning-icon';
                warningIcon.title = 'Disabled due to new permissions. Enable manually on the extension details page.';
                warningIcon.innerHTML = '⚠️';
                controls.appendChild(warningIcon);
            } else if (isLocal) {
                const localIndicator = document.createElement('span');
                localIndicator.className = 'local-indicator-icon';
                localIndicator.innerHTML = 'L';
                localIndicator.title = 'This extension is loaded locally.';
                controls.appendChild(localIndicator);
            } else if (ext.optionsUrl) {
                const optionsLink = document.createElement('a');
                optionsLink.className = 'options-icon';
                optionsLink.title = 'Options';
                optionsLink.innerHTML = '⚙️';
                optionsLink.href = "#";
                optionsLink.addEventListener('click', (e) => { e.preventDefault(); chrome.tabs.create({ url: ext.optionsUrl }); });
                controls.appendChild(optionsLink);
            } else if (ext.homepageUrl && !ext.optionsUrl) {
                const popupActionIcon = document.createElement('span');
                popupActionIcon.className = 'popup-action-icon';
                popupActionIcon.title = 'This extension has a toolbar popup action.';
                popupActionIcon.innerHTML = '🧩';
                controls.appendChild(popupActionIcon);
            }
            
            const toggleLabel = document.createElement('label');
            toggleLabel.className = 'switch';
            const toggleInput = document.createElement('input');
            toggleInput.type = 'checkbox';
            toggleInput.checked = ext.enabled;
            toggleInput.dataset.extensionId = ext.id;
            if (needsPermission) toggleInput.disabled = true;
            const slider = document.createElement('span');
            slider.className = 'slider';
            toggleLabel.appendChild(toggleInput);
            toggleLabel.appendChild(slider);
            toggleInput.addEventListener('change', handleIndividualToggle);
            controls.appendChild(toggleLabel);

            item.appendChild(icon);
            item.appendChild(name);
            item.appendChild(controls);
            return { element: item, enabled: ext.enabled };
        }));

        let separatorRendered = false;
        itemsToRender.filter(Boolean).forEach(itemData => {
            if (!sortByAZ && !itemData.enabled && !separatorRendered) {
                const separator = document.createElement('div');
                separator.className = 'list-separator';
                listContainer.appendChild(separator);
                separatorRendered = true;
            }
            listContainer.appendChild(itemData.element);
        });
    };

    const handleIndividualToggle = async (event) => {
        const extensionId = event.target.dataset.extensionId;
        const isEnabled = event.target.checked;
        await safeSetEnabled(extensionId, isEnabled);
        const item = event.target.closest('.extension-item');
        if (item) item.classList.toggle('disabled', !isEnabled);
        await initializeAllToggleStates();
        if (sortToggle.checked === false) {
             // Re-render to sort active/inactive correctly
            await renderExtensionsList();
        }
    };

    const handleGlobalToggle = async (event) => {
        const shouldEnableAll = event.target.checked;
        const extensions = await chrome.management.getAll();
        if (!shouldEnableAll) {
            const statesToSave = {};
            const disablePromises = [];
            for (const ext of extensions) {
                if (ext.id !== chrome.runtime.id && ext.enabled) {
                    statesToSave[ext.id] = true;
                    disablePromises.push(safeSetEnabled(ext.id, false));
                }
            }
            if (Object.keys(statesToSave).length > 0) {
                 await chrome.storage.local.set({ extensions_states_before_disable: statesToSave });
            }
            await Promise.all(disablePromises);
        } else {
            const result = await chrome.storage.local.get('extensions_states_before_disable');
            const savedStates = result.extensions_states_before_disable;
            if (savedStates) {
                const restorePromises = [];
                for (const id in savedStates) {
                     if (savedStates[id]) {
                         restorePromises.push(safeSetEnabled(id, true));
                     }
                }
                await Promise.all(restorePromises);
                await chrome.storage.local.remove('extensions_states_before_disable');
            }
        }
        await renderExtensionsList();
        await initializeAllToggleStates();
    };

    const handleAllExtensionsToggle = async (event) => {
        const shouldEnable = event.target.checked;
        const action = shouldEnable ? "enable" : "disable";
        const confirmed = window.confirm(`Are you sure you want to ${action} ALL extensions? REMEMBER !!! Ctrl+Shift+E to open this window list.`);
        if (!confirmed) {
            event.target.checked = !shouldEnable;
            return;
        }
        const extensions = await chrome.management.getAll();
        const togglePromises = [];
        for (const ext of extensions) {
            if (ext.id !== chrome.runtime.id && ext.disabledReason !== 'permissions_increase') {
                togglePromises.push(safeSetEnabled(ext.id, shouldEnable));
            }
        }
        await Promise.all(togglePromises);
        await chrome.storage.local.remove('extensions_states_before_disable');
        await renderExtensionsList();
        await initializeAllToggleStates();
    };

    const initializeAllToggleStates = async () => {
        const result = await chrome.storage.local.get('extensions_states_before_disable');
        globalToggle.checked = !result.extensions_states_before_disable;
        const extensions = await chrome.management.getAll();
        const allButSelf = extensions.filter(ext => ext.id !== chrome.runtime.id);
        if (allButSelf.length > 0) {
             allExtensionsToggle.checked = allButSelf.every(ext => ext.enabled);
        } else {
            allExtensionsToggle.checked = true;
        }
    };
    
    const initializeSortToggle = async () => {
        const result = await chrome.storage.local.get(SORT_MODE_KEY);
        const sortMode = result[SORT_MODE_KEY] || 'active_first';
        sortToggle.checked = sortMode === 'a_to_z';
    };

    const handleSortToggleChange = async (event) => {
        const newSortMode = event.target.checked ? 'a_to_z' : 'active_first';
        await chrome.storage.local.set({ [SORT_MODE_KEY]: newSortMode });
        await renderExtensionsList();
    };

    sortToggle.addEventListener('change', handleSortToggleChange);
    exportButton.addEventListener('click', () => { exportChoiceModal.style.display = 'flex'; });
    exportCancelBtn.addEventListener('click', () => { exportChoiceModal.style.display = 'none'; });
    exportTxtBtn.addEventListener('click', () => runExport('txt'));
    exportHtmlBtn.addEventListener('click', () => runExport('html'));
    importButton.addEventListener('click', handleImportClick);
    importInput.addEventListener('change', handleFileSelect);
    globalToggle.addEventListener('change', handleGlobalToggle);
    allExtensionsToggle.addEventListener('change', handleAllExtensionsToggle);

    await Promise.all([
        initializeAllToggleStates(),
        initializeSortToggle()
    ]);
    await renderExtensionsList();
});